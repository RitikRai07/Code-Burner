document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    
    // You can perform additional validation here before submitting the form
    // For simplicity, let's just log the values for now
    console.log('Username:', username);
    console.log('Email:', email);
    console.log('Password:', password);
  });
  